﻿namespace TextConvertor
{
    internal class Data
    {
        public string Name;
        public int Long;
        public int High;

        public Data(string name, int lang, int high)
        {
            Name = name;
            Long = lang;
            High = high;
        }
    }
}
