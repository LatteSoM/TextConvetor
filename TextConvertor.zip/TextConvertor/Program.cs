﻿using Newtonsoft.Json;
using System.Text;
using System.Xml.Serialization;
/*D:\Dec\Praka.txt*/
namespace TextConvertor
{
    internal class Program
    {
        public static string adres;
        public static int sort;
        

        static void Main()
        {
            Console.InputEncoding = Encoding.UTF8;
            Menu();
        }
        static void Menu()
        {
            Console.WriteLine("введите путь до файла (вместе с названием) который хотите открыть \r\n" +
                "------------------------------------------------------------------");
            adres = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("сохранить файл в одном из трех форматов (json,xml,txt) - F1. Закрыть прогу - Escape \r\n" +
                "------------------------------------------------------------------");
            string text = File.ReadAllText(adres);
            if (adres.Contains("json"))
            {
                List<Data> json = JsonConvert.DeserializeObject<List<Data>>(text);
                foreach (Data value in json)
                {
                    Console.WriteLine(value.Name);
                    Console.WriteLine(value.Long);
                    Console.WriteLine(value.High);
                }
            }
            else if (adres.Contains("xml"))
            {
                Data data;
                XmlSerializer xml = new XmlSerializer(typeof(Data));
                using (FileStream fs = new FileStream(adres, FileMode.Open))
                {
                    data = (Data)xml.Deserialize(fs);
                }
            }
            else
            {
                Console.WriteLine(text);
            }
            ConsoleKeyInfo key = Console.ReadKey();
            if (key.Key == ConsoleKey.F1)
            {

                Console.Clear();
                Convertor();
            }
            else if (key.Key == ConsoleKey.Escape)
            {
                Console.WriteLine("lox");
            }
        }
        static void Convertor()
        {
            Console.WriteLine("введите путь до файла (вместе с названием) куда вы хотите сохранить \r\n" +
               "------------------------------------------------------------------");
            string FinalAdres = Console.ReadLine();

            if (FinalAdres.Contains("json"))
            {
                string a = JsonConvert.SerializeObject(info());
                File.WriteAllText(FinalAdres, a);
            }
            else if (FinalAdres.Contains("xml"))
            {
                List<Data> datas = info();

                XmlSerializer xml = new XmlSerializer(typeof(Data));
                using (FileStream fs = new FileStream(FinalAdres, FileMode.OpenOrCreate))
                {
                    xml.Serialize(fs, datas);
                }
            }
            else
            {
                Console.WriteLine("xdcfghjk");
            }
        }
        static List<Data> info()
        {

            Data[] Pramo = new Data[]{};
            string[] lines = File.ReadAllLines(adres);
            for (int i = 0; i < lines.Length; i+=3)
            {
                
                Pramo.Append(new Data(lines[i], Convert.ToInt32(lines[i + 1]), Convert.ToInt32(lines[i + 2])));
            }
            
            return Pramo.ToList();
        }
    }
}